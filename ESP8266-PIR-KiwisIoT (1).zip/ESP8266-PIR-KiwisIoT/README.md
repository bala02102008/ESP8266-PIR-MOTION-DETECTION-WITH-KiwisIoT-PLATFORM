<div align="center">

# PIR Motion Detection Using ESP8266 and KiwisIoT Platform

![Banner](images/banner.png)

![Board](https://img.shields.io/badge/Board-ESP8266%20NodeMCU-red)
![Sensor](https://img.shields.io/badge/Sensor-PIR-blue)
![Platform](https://img.shields.io/badge/Platform-KiwisIoT-orange)
![IDE](https://img.shields.io/badge/IDE-Arduino-00979D)
![License](https://img.shields.io/badge/License-MIT-green)

</div>

## 🚀 Project Overview

This project detects human movement using a **PIR sensor** and an **ESP8266 NodeMCU**.
When motion is detected, the ESP8266 sends the motion status to the **KiwisIoT Platform** through Wi-Fi.
The dashboard shows the result as **True** (motion detected) or **False** (no motion), so you can monitor movement in real time.

## ✨ Features

- Real-time motion detection
- ESP8266 Wi-Fi connectivity
- PIR sensor integration
- KiwisIoT Platform dashboard integration
- Live True / False status display
- Beginner-friendly IoT project

## 🧰 Components Required

| Component | Quantity |
|-----------|----------|
| ESP8266 NodeMCU | 1 |
| PIR Sensor | 1 |
| Jumper Wires | 3 |
| USB Cable | 1 |
| Computer | 1 |

## 🔌 Circuit Connections

| PIR Sensor | ESP8266 NodeMCU |
|------------|-----------------|
| VCC | 3.3V |
| GND | GND |
| OUT | D7 |

![Circuit Diagram](images/circuit-diagram.png)

## ⚙️ How It Works

1. The PIR sensor detects movement.
2. The ESP8266 reads the sensor signal on pin **D7**.
3. If the signal is `HIGH`, the status becomes **True**; if `LOW`, it becomes **False**.
4. The ESP8266 sends the status to the KiwisIoT Platform over Wi-Fi.
5. The KiwisIoT dashboard displays the current motion status.

```
PIR Sensor → ESP8266 → Wi-Fi → KiwisIoT → Dashboard
```

## 📊 Dashboard Output

| Value | Meaning |
|-------|---------|
| `True` | Motion detected |
| `False` | No motion detected |

The dashboard receives the data through **Channel 0** using a **Label** widget.

![Dashboard Output](images/dashboard-output.png)

## 💻 Software Used

- Arduino IDE
- ESP8266 Board Package
- KiwisIoT Arduino Library
- KiwisIoT Platform

## ⬆️ Getting Started

1. Install the **Arduino IDE** and the **ESP8266 board package**.
2. Install the **KiwisIoT Arduino library** (see the [KiwisIoT Arduino Setup Guide](https://github.com/Kiwistron/KiwisIoT-Projects/tree/main/esp8266/kiwisiot-arduino-setup)).
3. Create a panel on the KiwisIoT Platform, add a **Label** widget on **Channel 0**, and copy the panel **Topic ID**.
4. Open `code/esp8266-pir-kiwisiot/esp8266-pir-kiwisiot.ino` in the Arduino IDE.
5. Replace the placeholders with your own details:

   ```cpp
   const char* ssid  = "YOUR_WIFI_NAME";
   const char* pass  = "YOUR_WIFI_PASSWORD";
   const char* topic = "YOUR_DASHBOARD_TOPIC_ID";
   ```

6. Select **NodeMCU 1.0 (ESP-12E Module)** as the board and the correct COM port.
7. Click **Upload**, then open the **Serial Monitor** at **115200 baud**.

> ⚠️ **Security:** never commit your real Wi-Fi password or Topic ID to a public repository.

## 🖥️ Serial Monitor Output

```
---------- PIR MONITORING ----------
PIR Sensor Value: 1
Motion Status: True
Motion: DETECTED
Sent to KiwisIoT Channel 0: True
```

## 📷 Real-Time Image

![Real-time setup](images/real-time-setup.jpg)

## 🛠️ Troubleshooting

| Problem | Things to check |
|---------|-----------------|
| Dashboard shows no data | Wi-Fi name/password, Topic ID, Channel 0 on the widget, internet connection |
| Always `True` or unstable | Wait ~30–60 s after power-up for the PIR to warm up; keep it away from heat sources and Wi-Fi antenna |
| No motion detected | Check VCC/GND/OUT wiring and that OUT goes to **D7** |
| Status looks reversed | Confirm the PIR module output is active-HIGH |

## 🌍 Applications

- Smart home monitoring
- Room occupancy detection
- Motion monitoring
- Smart lighting systems
- IoT-based monitoring

## 🔮 Future Improvements

- LED indicators
- Buzzer alerts
- Notifications
- Smart home automation features

## 📁 Project Structure

```
ESP8266-PIR-KiwisIoT/
├── README.md
├── LICENSE
├── .gitignore
├── code/
│   └── esp8266-pir-kiwisiot/
│       └── esp8266-pir-kiwisiot.ino
└── images/
    ├── banner.png
    ├── circuit-diagram.png
    ├── dashboard-output.png
    └── real-time-setup.jpg
```

## 📌 Conclusion

This project demonstrates a simple way to monitor motion using IoT technology. By combining a PIR sensor, an ESP8266 NodeMCU and the KiwisIoT Platform, motion status can be monitored remotely through an IoT dashboard.

## 🔗 Links

- [KiwisIoT Projects collection](https://github.com/Kiwistron/KiwisIoT-Projects)
- [KiwisIoT Arduino Setup Guide](https://github.com/Kiwistron/KiwisIoT-Projects/tree/main/esp8266/kiwisiot-arduino-setup)

## 📄 License

Released under the [MIT License](LICENSE).
